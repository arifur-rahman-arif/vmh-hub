<?php
if ( !function_exists( 'add_action' ) ) {
    exit;
}

//Index.php